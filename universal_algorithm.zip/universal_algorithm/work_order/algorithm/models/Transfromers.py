from models.lr import LR
from layers.ctr_layers import CIN, DeepLayer, InteractingLayer
import tensorflow as tf


class Transfromers(LR):
    def __init__(self, text_model, schema_dict, embedding_size, hidden_units, steps=None, model_dir=None,
                 output_mode=1, output_num=2, model_type='regression'):
        super(Transfromers, self).__init__(text_model, schema_dict, embedding_size, steps, model_dir, output_mode, output_num, model_type)
        self.hidden_units = hidden_units

    def network(self, input):
        embedding, texts_embedding, numerical, vector, sparse_linear = self.feature_engineer(input)
        deep_in = tf.concat(texts_embedding, -1)
        deep_out = DeepLayer(self.hidden_units)(deep_in)
        return deep_out

    #��������Ǹ�
    def prediction_type(self, mode, predictions, features):
        return tf.estimator.EstimatorSpec(mode, predictions={'predictions': predictions})


    #������������
    def prediction_types(self, mode, predictions, features):
        return tf.estimator.EstimatorSpec(mode, predictions={'predictions': tf.sort(predictions, direction='DESCENDING'),
                                                             'label_ids': tf.argsort(predictions, direction='DESCENDING')})
