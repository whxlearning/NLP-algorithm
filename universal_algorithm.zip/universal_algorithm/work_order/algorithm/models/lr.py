from algorithm.models.model import Model
from algorithm.layers.ctr_layers import DeepLayer
from algorithm.layers.embedding_layers import *
from tensorflow.keras.layers import Dense
import json


class LR(Model):
    """
    推荐类模型基类，提供各种特征embedding功能
    """

    def __init__(self, text_model, schema_dict, embedding_size=None, steps=None, model_dir=None, output_mode=1,
                 output_num=2, model_type='regression'):
        super(LR, self).__init__(steps=steps, model_dir=model_dir, output_mode=output_mode, output_num=output_num, model_type=model_type)
        if isinstance(schema_dict, dict):
            self._schema_dict = schema_dict
        elif isinstance(schema_dict, str):
            with open(schema_dict, "r", encoding='utf-8') as f:
                self._schema_dict = json.load(f)
        else:
            raise TypeError
        self._embedding_size = embedding_size
        self._num_labels = len(self._schema_dict['label_list'])
        self.text_model = text_model

    def network(self, input):
        sparse_linear, sparse_embedding, seq_embedding, numerical, texts_embedding, vector = self.feature_engineer(input)
        network_out = tf.concat(embedding + numerical + sparse_linear, -1)
        return network_out

    def feature_engineer(self, features):

        # 离散特征one-hot
        sparse_linear_layers = {k: tf.squeeze(tf.one_hot(features[k], v, name='sparse_linear_' + k), 1) for k, v in
                                self._schema_dict['sparse_feature'].items()}
        sparse_linear = [v for k, v in sparse_linear_layers.items()]

        # 离散特征embedding
        sparse_embedding_layers = {k : tf.keras.layers.Embedding(v, self.get_embedding_size(v), mask_zero=True, name='embedding_' + k) for k, v in
        self._schema_dict['sparse_feature'].items()}
        sparse_embedding = [tf.squeeze(v(features[k]), 1) for k, v in sparse_embedding_layers.items()]

        # 多值离散特征embedding
        seq_embedding_layers = {
        k: tf.keras.layers.Embedding(v['vocab_size'] + 1, self.get_embedding_size(v['vocab_size']), mask_zero=True,
                                     name='seq_embedding_' + k) for k, v in self._schema_dict['seq_feature'].items()}
        seq_embedding = [tf.reduce_mean(v(features[k]), 1) for k, v in seq_embedding_layers.items()]


        # 连续特征
        numerical = [features[d] for d in self._schema_dict['dense_feature']]

        # 文本特征三维处理方法
        texts_embedding = list()
        for k, v in self._schema_dict['text_feature'].items():
            text_embedding_size = self.get_embedding_size(v['vocab_size'])
            text_embedding = tf.keras.layers.Embedding(v['vocab_size'] + 1, text_embedding_size, mask_zero=True, name='text_embedding_' + k)(features[k])
            text_embedding = SinusoidalPositionEmbedding()(text_embedding)
            if self.text_model == 'BiLSTM':
                text_res = BiLSTM(text_embedding_size, v['len'])(text_embedding)
            elif self.text_model == 'BiGRU':
                text_res = BiGRU(text_embedding_size, v['len'])(text_embedding)
            elif self.text_model == 'RCNN_variant':
                text_res = RCNN_variant(text_embedding_size, v['len'])(text_embedding)
            elif self.text_model == 'TextAttBiRNN':
                text_res = TextAttBiRNN(text_embedding_size, v['len'])(text_embedding)
            elif self.text_model == 'Transformer':
                text_res = Transformer(text_embedding_size, v['len'])(text_embedding)
            elif self.text_model == 'DPCNN':
                text_res = DPCNN(text_embedding_size, v['len'])(text_embedding)
            elif self.text_model == 'CRNN':
                text_res = CRNN(text_embedding_size, v['len'])(text_embedding)
            elif self.text_model == 'Capnet_CNN':
                print("===================Using Capnet_CNN Model================")
                text_res = Capnet_CNN(text_embedding_size, v['en'])(text_embedding)
            elif self.text_model == 'Capnet_RNN':
                print("===================Using Capnet_RNN Model================")
                text_res = Capnet_RNN(text_embedding_size, v['len'])(text_embedding)
            elif self.text_model == 'Bert_CNN':
                print("===================Using Capnet_RNN Model================")
                text_res = Bert_CNN(text_embedding_size, v['len'])(text_embedding)
            elif self.text_model == 'Bert_RNN':
                print("===================Using Capnet_RNN Model================")
                text_res = Bert_RNN(text_embedding_size, v['len'])(text_embedding)
            elif self.text_model == 'CNN_LSTM':
                print("===================Using Capnet_RNN Model================")
                text_res = CNN_LSTM(text_embedding_size, v['len'])(text_embedding)
            else:
                text_res = TextCNN(text_embedding_size, v['len'])(text_embedding)
            text_embed = Dense(text_embedding_size)(text_res)
            texts_embedding.append(text_embed)

        # 文本特征的二维处理方法
        # vector = [DeepLayer([self._embedding_size])(features[v]) for v in self._schema_dict['vector_feature'].keys()]
        # for v in self._schema_dict['vector_feature'].keys():
        #     print(features[v])
        #     print(type(features[v]))
        vector = [features[v] for v in self._schema_dict['vector_feature'].keys()]

        #向量合并
        return sparse_linear, sparse_embedding, seq_embedding, numerical, texts_embedding, vector

    def get_embedding_size(self, vocab_size):
        return self._embedding_size if self._embedding_size else int(vocab_size ** 0.25 * 6)

    @staticmethod
    def model_metric(labels, predictions):
        ones = tf.ones_like(labels)
        zeros = tf.zeros_like(labels)
        pres = tf.where(predictions >= 0.5, ones, zeros)
        #label_id = tf.argmax(labels, axis=-1, output_type=tf.int32)
        acc = tf.metrics.accuracy(labels, pres)
        auc = tf.metrics.auc(labels, predictions)
        # mse = tf.reduce_mean(tf.square(labels - predictions))
        return {'acc': acc, 'auc': auc}

    # 模型损失函数
    @staticmethod
    def model_loss_regression(labels, predictions):
        return tf.reduce_mean(tf.square(labels - predictions))

    @staticmethod
    def model_loss_2(labels, predictions):
        return tf.losses.log_loss(labels, predictions)

    @staticmethod
    def model_loss_more(labels, predictions):
        # 损失函数调参
        #根据类别决定维度，有多少类，labels、predictions的维度就有多少
        # weights = [1, 32]
        # weights = tf.convert_to_tensor(weights)
        # weights = tf.cast(weights, tf.float32)
        # weights = tf.reduce_sum(tf.multiply(labels, weights), -1)
        # return tf.losses.softmax_cross_entropy(labels, predictions, weights=weights)
        return tf.losses.softmax_cross_entropy(labels, predictions)

    @staticmethod
    def model_optimizer():
        return tf.train.AdamOptimizer()

    #接下来最后一层全连接层如何设计？

    # 模型最终输出结果(回归)
    def model_predictions_regression(self, network_out):
        return tf.layers.dense(network_out, 1, activation="relu")

    # 模型最终输出结果(二分类)
    def model_predictions_2(self, network_out):
        return tf.layers.dense(network_out, 1, activation='sigmoid')
        #return tf.layers.dense(network_out, 2)

    # 模型最终输出结果(多分类)
    def model_predictions_more(self, network_out):
        return tf.layers.dense(network_out, self._num_labels)

    def _receiver_fn(self):
        features = dict()
        for name in self._schema_dict['dense_feature']:
            features[name] = tf.placeholder(dtype=tf.float32, shape=[None, 1])
        for name in self._schema_dict['sparse_feature']:
            features[name] = tf.placeholder(dtype=tf.int64, shape=[None, 1])
        for name in self._schema_dict['vector_feature']:
            features[name] = tf.placeholder(dtype=tf.float32, shape=[None, self._schema_dict['vector_feature'][name]])
        for name in self._schema_dict['seq_feature']:
            features[name] = tf.placeholder(dtype=tf.float32, shape=[None, self._schema_dict['seq_feature'][name]['len']])
        for name in self._schema_dict['text_feature']:
            features[name] = tf.placeholder(dtype=tf.float32, shape=[None, self._schema_dict['text_feature'][name]['len']])
        return tf.estimator.export.build_raw_serving_input_receiver_fn(features)


