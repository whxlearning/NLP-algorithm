from models.lr import LR
from layers.ctr_layers import CIN, DeepLayer
import tensorflow as tf

class XFM(LR):
    def __init__(self, text_model, schema_dict, embedding_size, hidden_units, layer_size=(128, 128), activation='relu',
                 split_half=True, l2_reg=1e-5, steps=None, model_dir=None, output_mode=1, output_num=2, model_type='regression'):
        super(XFM, self).__init__(text_model, schema_dict, embedding_size, steps, model_dir, output_mode, output_num, model_type=model_type)
        self.hidden_units = hidden_units
        self.layer_size = layer_size
        self.activation = activation
        self.split_half = split_half
        self.l2_reg = l2_reg
        self.text_model = text_model

    def network(self, input):
        sparse_linear, sparse_embedding, seq_embedding, numerical, texts_embedding, vector = self.feature_engineer(input)

        # lr部分
        linear_in = tf.concat(sparse_linear, -1)
        linear_out = DeepLayer(hidden_units=self.hidden_units, activation=self.activation)(linear_in)
        # dnn部分
        deep_in = tf.concat(sparse_embedding, -1)
        deep_out = DeepLayer(self.hidden_units)(deep_in)
        # AutoInt
        # interacting_in = tf.stack(embedding, axis=1)
        # autoint_out = InteractingLayer()(interacting_in)
        # autoint_out = tf.keras.layers.Flatten()(autoint_out)

        # CIN层
        cin_in = tf.stack(sparse_embedding, axis=1)
        cin_out = CIN(layer_size=self.layer_size, activation=self.activation, split_half=self.split_half,
                      l2_reg=self.l2_reg)(cin_in)

        out = tf.concat((linear_out, deep_out, cin_out), -1)

        return out

    #输出最大的那个
    def prediction_type(self, mode, predictions, features):
        return tf.estimator.EstimatorSpec(mode, predictions={'predictions': predictions})


    #按降序输出多个
    def prediction_types(self, mode, predictions, features):
        return tf.estimator.EstimatorSpec(mode, predictions={'predictions': tf.sort(predictions, direction='DESCENDING'),
                                                             'label_ids': tf.argsort(predictions, direction='DESCENDING')})
