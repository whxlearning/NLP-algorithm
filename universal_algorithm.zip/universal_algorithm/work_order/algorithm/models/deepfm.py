from models.lr import LR
from layers.ctr_layers import DeepLayer, BiInteractionPooling
import tensorflow as tf



class DeepFM(LR):
    def __init__(self, text_model, schema_dict, embedding_size, hidden_units, layer_size=(128, 128), activation='relu',
                 split_half=True, l2_reg=1e-5, steps=None, model_dir=None, output_mode=1, output_num=2, model_type='regression'):
        super(DeepFM, self).__init__(text_model, schema_dict, embedding_size, steps, model_dir, output_mode, output_num, model_type=model_type)
        self.hidden_units = hidden_units
        self.layer_size = layer_size
        self.activation = activation
        self.split_half = split_half
        self.l2_reg = l2_reg
        self.text_model = text_model

    def network(self, input):
        sparse_linear, sparse_embedding, seq_embedding, numerical, texts_embedding, vector = self.feature_engineer(input)

        # dnn����
        deep_in = tf.concat(sparse_embedding, -1)
        deep_out = DeepLayer(self.hidden_units)(deep_in)

        # FM����
        bi_interaction_pooling = BiInteractionPooling()
        embedding_bi = tf.stack(sparse_embedding, axis=1)
        bi_out = bi_interaction_pooling(embedding_bi)

        out = tf.concat((deep_out, bi_out), -1)

        return out

    #��������Ǹ�
    def prediction_type(self, mode, predictions, features):
        return tf.estimator.EstimatorSpec(mode, predictions={'predictions': predictions})


    #������������
    def prediction_types(self, mode, predictions, features):
        return tf.estimator.EstimatorSpec(mode, predictions={'predictions': tf.sort(predictions, direction='DESCENDING'),
                                                             'label_ids': tf.argsort(predictions, direction='DESCENDING')})
