from models.lr import LR
from layers.ctr_layers import BiInteractionPooling
import tensorflow as tf



class FM(LR):

    def network(self, input):
        sparse_linear, sparse_embedding, seq_embedding, numerical, texts_embedding, vector = self.feature_engineer(input)
        bi_interaction_pooling = BiInteractionPooling()
        embedding_bi = tf.stack(sparse_embedding, axis=1)
        bi_out = bi_interaction_pooling(embedding_bi)
        network_out = tf.concat([bi_out] + sparse_embedding, -1)
        return network_out

    def prediction_type(self, mode, predictions, features):
        return tf.estimator.EstimatorSpec(mode, predictions={'predictions': predictions,
                                                             'label_ids': tf.argmax(predictions, axis=-1)})

    #   ��������п��Ը���Ϊ'label_ids':tf.argsort(predictions,direction='DESCENDING')����ʾ����Ԥ��ĸ��ʽ����±�����
    #   'label_ids': tf.argmax(predictions, axis=-1)��ʾ�������ֵ
    def prediction_types(self, mode, predictions, features):
        return tf.estimator.EstimatorSpec(mode, predictions={'predictions': predictions,
                                                             'label_ids': tf.argsort(predictions,
                                                                                     direction='DESCENDING')})
