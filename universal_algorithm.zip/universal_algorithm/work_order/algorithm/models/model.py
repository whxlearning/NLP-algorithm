import tensorflow as tf

class Model(object):
    """
    模型基类，提供模型配置，训练，验证，预测以及模型服务文件生成功能
    """

    def __init__(self, steps=None, model_dir=None, output_mode=1, output_num=2, model_type='regression'):
        self._steps = steps
        self._model_dir = model_dir
        self.output_mode = output_mode             # 模型的输出格式
        self.output_num = output_num               # 二分类还是多分类
        self.model_type = model_type               # 回归 or 分类
        self.estimator = self._build_estimator()

    def _build_estimator(self):
        sess_config = tf.ConfigProto(allow_soft_placement=True)
        sess_config.gpu_options.allow_growth = True
        strategy = tf.distribute.experimental.ParameterServerStrategy()
        config = tf.estimator.RunConfig(train_distribute=strategy)  # 使用分布式的时候使用该config
        return tf.estimator.Estimator(self.build_model(), config=None, model_dir=self._model_dir)

    def build_model(self):
        def model_fn(features, labels, mode, params):
            network_out = self.network(features)
            # 训练、验证
            if mode == tf.estimator.ModeKeys.TRAIN or mode == tf.estimator.ModeKeys.EVAL:
                if self.model_type == 'classify':
                    if self.output_num == 2:
                        predictions = self.model_predictions_2(network_out)      # 二分类
                        loss = self.model_loss_2(labels, predictions)
                    else:
                        predictions = self.model_predictions_more(network_out)   # 多分类
                        loss = self.model_loss_more(labels, predictions)

                else:
                    predictions = self.model_predictions_regression(network_out)
                    loss = self.model_loss_regression(labels, predictions)

                metrics = self.model_metric(labels, predictions)  # 根据模型预测值与真实标签计算一些指标

                if mode == tf.estimator.ModeKeys.EVAL:
                    return tf.estimator.EstimatorSpec(mode=mode, loss=loss, eval_metric_ops=metrics)
                else:
                    train_op = self.model_train_op(loss)
                    return tf.estimator.EstimatorSpec(mode=mode, loss=loss, train_op=train_op)
            # 预测
            else:
                if self.model_type == 'classify':
                    if self.output_num == 2:
                        predictions = self.model_predictions_2(network_out)      # 二分类
                    else:
                        predictions = self.model_predictions_more(network_out)   # 多分类
                else:
                    predictions = self.model_predictions_regression(network_out)

                if self.output_mode == 1:
                    return self.prediction_types(mode, predictions, features)
                else:
                    return self.prediction_type(mode, predictions, features)

            #metrics = self.model_metric(labels, predictions)  #根据模型预测值与真实标签计算一些指标

            # if mode == tf.estimator.ModeKeys.EVAL:
            #     return tf.estimator.EstimatorSpec(mode, loss=loss, eval_metric_ops=metrics)
            #     #pass
            #
            # #assert mode == tf.estimator.ModeKeys.TRAIN
            # train_op = self.model_train_op(loss)
            # return tf.estimator.EstimatorSpec(mode=mode, loss=loss, train_op=train_op)

        return model_fn

    def network(self, input):
        raise NotImplementedError

    def prediction_type(self, mode, predictions, features):
        return tf.estimator.EstimatorSpec(mode, predictions=predictions)

    def prediction_types(self, mode, predictions, features):
        raise NotImplementedError

    def fit(self, train_set, eval_set=None, patient=None, metric=None):
        if eval_set:
            hook = tf.contrib.estimator.stop_if_no_increase_hook(self.estimator, metric,
                                                                 max_steps_without_increase=patient)
            train_spec = tf.estimator.TrainSpec(input_fn=train_set.parsed_data, hooks=[hook])
            eval_spec = tf.estimator.EvalSpec(input_fn=eval_set.parsed_data)
            return tf.estimator.train_and_evaluate(self.estimator, train_spec, eval_spec)
        else:
            self.estimator.train(train_set.parsed_data, steps=self._steps)  #批量训练数据

    def train_and_eval(self, trainset, validset):
        tf.estimator.train_and_evaluate(
            self.estimator,
            train_spec=tf.estimator.TrainSpec(input_fn=trainset.parsed_data),
            eval_spec=tf.estimator.EvalSpec(input_fn=validset.parsed_data)
        )

    def predict(self, data_set):
        return self.estimator.predict(data_set.parsed_data)

    def eval(self, data_set):
        return self.estimator.evaluate(data_set.parsed_data)

    def save_for_server(self, model_dir):
        self.estimator.export_saved_model(model_dir, serving_input_receiver_fn=self._receiver_fn())

    @staticmethod
    def model_loss_regression(labels, predictions):
        raise NotImplementedError

    @staticmethod
    def model_loss_2(label, predictions):
        raise NotImplementedError

    @staticmethod
    def model_loss_more(label, predictions):
        raise NotImplementedError

    @staticmethod
    def model_metric(label, predictions):
        raise NotImplementedError

    @staticmethod
    def model_optimizer():
        raise NotImplementedError

    @staticmethod
    def model_predictions_regression(network_out):
        raise NotImplementedError

    @staticmethod
    def model_predictions_2(network_out):
        raise NotImplementedError

    @staticmethod
    def model_predictions_more(network_out):
        raise NotImplementedError

    def model_train_op(self, loss):
        optimizer = self.model_optimizer()
        train_op = optimizer.minimize(loss, global_step=tf.train.get_global_step())
        return train_op

    def _receiver_fn(self):
        raise NotImplementedError
