import json
from tensorflow.keras.preprocessing.text import Tokenizer
import tensorflow as tf

flags = tf.flags
FLAGS = flags.FLAGS


# 生成模型大纲文件
def build_schema_dict(data, dense_feature, sparse_feature, seq_feature, vector_dict, text_feature,
                      label, label_list, schema_path=None, vocab_path=None):
    schema_dict = dict()
    schema_dict['sparse_feature'] = {}  #离散特征使用字典储存，格式为：特征名->词表大小
    schema_dict['seq_feature'] = {}
    schema_dict['text_feature'] = {}
    schema_dict['seq_feature_vocab'] = {}
    schema_dict['text_feature'] = {}
    schema_dict['text_feature_vocab'] = {}
    for s in sparse_feature:
        schema_dict['sparse_feature'][s] = data[s].nunique()

    for m_s in seq_feature:
        desc = dict()
        word_dict, vocab_size, max_len = get_seq_feature(data, m_s)
        desc['vocab_size'] = vocab_size
        desc['seq_sep_feature'] = FLAGS.seq_sep_feature
        schema_dict['seq_feature_vocab'][m_s] = word_dict
        desc['len'] = max_len
        schema_dict['seq_feature'][m_s] = desc

    for t_s in text_feature:
        desc = dict()
        word_dict, vocab_size, max_len = get_text_feature(data, t_s)
        desc['vocab_size'] = vocab_size
        schema_dict['text_feature_vocab'][t_s] = word_dict
        desc['len'] = max_len
        schema_dict['text_feature'][t_s] = desc

    schema_dict['vector_feature'] = vector_dict

    schema_dict['sparse_feature_vocab'] = build_vocab_dict(data, sparse_feature, vocab_path)  # 生成离散特征映射表


    schema_dict['dense_feature'] = {}  #连续特征使用列表储存，格式为：[特征名1， 特征名2，。。。。。。]
    for d in dense_feature:
        schema_dict['dense_feature'][d] = data[d].mean()
    schema_dict['label'] = label  # 标签的名字
    schema_dict['label_list'] = label_list  # 标签的类别
    # if sample_id:  # 样本id
    #     schema_dict['sample_id'] = sample_id
    if schema_path:
        with open(schema_path, "w", encoding='utf-8') as f:
            json.dump(schema_dict, f, ensure_ascii=False, indent=4)
    return schema_dict

# 生成离散特征映射表
def build_vocab_dict(data, sparse_feature, vocab_path=None):
    vocab = dict()
    for s in sparse_feature:
        sparse_list = data[s].unique().tolist()
        vocab[s] = dict()
        for index, value in enumerate(sparse_list):
            vocab[s][value] = index
    if vocab_path:
        with open(vocab_path, "w", encoding='utf-8') as f:
            json.dump(vocab, f, ensure_ascii=False, indent=4)
    return vocab

# 生成多值离散特征映射表
def get_seq_feature(data, feature):
    text_list = data[feature]        #是一个列表
    max_len = text_list.apply(lambda x: len(x.split(FLAGS.seq_sep_feature))).max()
    tokenizer = Tokenizer(filters='', lower=False, split=FLAGS.seq_sep_feature) #序列化
    tokenizer.fit_on_texts(text_list)
    word_dict = tokenizer.word_index
    vocab_size = len(word_dict)
    return word_dict, vocab_size, int(max_len)

# 生成序列特征映射表
def get_text_feature(data, feature):
    text_list = data[feature]        #是一个列表
    max_len = text_list.apply(lambda x: len(x)).max()
    word_dict = {}
    count = 0
    for sentence in data[feature]:
        for char in sentence:
            if char not in word_dict:
                word_dict[char] = count
                count +=1

    vocab_size = len(word_dict)
    return word_dict, vocab_size, int(max_len)