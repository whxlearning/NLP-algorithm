import tensorflow as tf


class DataSet(object):
    """
    数据载入器，负责读取解析tfrecord文件以及配置数据迭代格式
    """

    def __init__(self, tfrecord_path, is_train=False, epochs=5, batch_size=32, shuffle_buffer_size=100,prefetch_buffer_size=100, output_num=2):
        self._epochs = epochs
        self._batch_size = batch_size
        self.output_num = output_num
        self._shuffle_buffer_size = shuffle_buffer_size
        self._prefetch_buffer_size = prefetch_buffer_size
        self._tfrecord_path = tfrecord_path
        self._is_train = is_train

    def _parse_function(self, example_proto):
        raise NotImplementedError

    def parsed_data(self):
        filenames = self._tfrecord_path
        if isinstance(filenames, list):
            filenames = tf.data.Dataset.from_tensor_slices(filenames)
            parsed_dataset = filenames.interleave(tf.data.TFRecordDataset, cycle_length=20, block_length=32)
        else:
            parsed_dataset = tf.data.TFRecordDataset(filenames)
        if self._is_train:
            parsed_dataset = parsed_dataset.shuffle(buffer_size=self._shuffle_buffer_size)
            parsed_dataset = parsed_dataset.repeat(self._epochs)
        parsed_dataset = parsed_dataset.map(self._parse_function)
        parsed_dataset = parsed_dataset.batch(self._batch_size)
        parsed_dataset = parsed_dataset.prefetch(buffer_size=self._prefetch_buffer_size)
        return parsed_dataset
