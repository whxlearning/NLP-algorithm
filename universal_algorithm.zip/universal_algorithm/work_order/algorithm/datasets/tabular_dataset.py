import tensorflow as tf
import json
from ..datasets.dataset import DataSet


flags = tf.flags
FLAGS = flags.FLAGS
flags.DEFINE_integer("info_step", 10000, "every step to logging")

class TabularDataSet(DataSet):

    """
    tfrecord类数据读取器
    """
    #初始化
    def __init__(self, schema_dict, tfrecord_path, is_train=False, epochs=5, batch_size=32, shuffle_buffer_size=100,
                 prefetch_buffer_size=100, output_num=2):
        super(TabularDataSet, self).__init__(tfrecord_path, is_train, epochs, batch_size, shuffle_buffer_size,
                                             prefetch_buffer_size, output_num=output_num)
        self.output_num = output_num
        if isinstance(schema_dict, dict):
            self._schema_dict = schema_dict
        elif isinstance(schema_dict, str):
            with open(schema_dict, "r", encoding='utf-8') as f:
                self._schema_dict = json.load(f)
        else:
            raise TypeError
        self._num_labels = len(self._schema_dict['label_list'])
        self._feature_description = self._make_feature()

    #定义读取tfrecord时各特征的维度大小、类型等性质
    def _make_feature(self):
        feature_description = {}

        for d in self._schema_dict['dense_feature']:
            feature_description[d] = tf.io.FixedLenFeature((1,), tf.float32)

        for s in self._schema_dict['sparse_feature'].keys():
            feature_description[s] = tf.io.FixedLenFeature((1,), tf.int64, default_value=0)

        for m_s in self._schema_dict['seq_feature'].keys():
            feature_description[m_s] = tf.io.FixedLenFeature((self._schema_dict['seq_feature'][m_s]['len'],), tf.float32)  # 多值离散特征是不定长的

        for v in self._schema_dict['vector_feature'].keys():
            feature_description[v] = tf.io.FixedLenFeature((self._schema_dict['vector_feature'][v],), tf.float32)

        for t in self._schema_dict['text_feature'].keys():
            feature_description[t] = tf.io.FixedLenFeature((self._schema_dict['text_feature'][t]['len'],), tf.float32)

        if self._is_train:
            if self.output_num == 2:
                feature_description[self._schema_dict['label']] = tf.io.FixedLenFeature((1,), tf.float32)
            else:
                feature_description[self._schema_dict['label']] = tf.io.FixedLenFeature((self._num_labels,), tf.float32)
        return feature_description

    #这函数有什么作用？？？
    def _parse_function(self, example_proto):
        feature = tf.io.parse_single_example(example_proto, self._feature_description)
        if self._is_train:
            label = feature.pop(self._schema_dict['label'])
            return feature, label
        return feature


class TfrecordBuilder(object):
    """
    pandas的DataFrame格式转换为tfrecord文件
    """
    def __init__(self, data, schema_dict, tfrecord_path, output_num):
        self._data = data
        self._tfrecord_path = tfrecord_path
        self.output_num = output_num
        if isinstance(schema_dict, dict):
            self._schema_dict = schema_dict
        elif isinstance(schema_dict, str):
            with open(schema_dict, "r", encoding='utf-8') as f:
                self._schema_dict = json.load(f)
        else:
            raise TypeError
        self._num_labels = len(self._schema_dict['label_list'])
        self._write_tfrecord()

    def _write_tfrecord(self):
        with tf.io.TFRecordWriter(self._tfrecord_path) as writer:
            for index, row in self._data.iterrows():
                if index % FLAGS.info_step == 1:
                    tf.logging.info(index)
                example = self._serialize_example(row)
                writer.write(example)

    def _serialize_example(self, row):
        feature = {}
        for d in self._schema_dict['dense_feature']:
            feature[d] = tf.train.Feature(float_list=tf.train.FloatList(value=[row[d]]))
        for s in self._schema_dict['sparse_feature'].keys():
            feature[s] = tf.train.Feature(int64_list=tf.train.Int64List(value=[int(row[s])]))
        for v in self._schema_dict['vector_feature'].keys():
            feature[v] = tf.train.Feature(float_list=tf.train.FloatList(value=row[v].tolist())) #tolist是把np数组变为list
        for s in self._schema_dict['seq_feature'].keys():
            feature[s] = tf.train.Feature(float_list=tf.train.FloatList(value=row[s]))
        for s in self._schema_dict['text_feature'].keys():
            feature[s] = tf.train.Feature(float_list=tf.train.FloatList(value=row[s]))

        if 'label' in self._schema_dict:  #如果有字典的键为label
            #如果是多分类需要构造one-hot，二分类就直接返回值即可
            if self.output_num > 2:
                value = row[self._schema_dict['label']]  #获取label2的实际值
                labels = [0] * self._num_labels
                labels[self._schema_dict['label_list'].index(value)] = 1
                #labels[0] = 1                                                #处理预测时标签不在训练集大纲中的情况???为什么要这么写？？
                feature[self._schema_dict['label']] = tf.train.Feature(float_list=tf.train.FloatList(value=labels))
            else:
                value = row[self._schema_dict['label']]  # 获取label2的实际值
                feature[self._schema_dict['label']] = tf.train.Feature(float_list=tf.train.FloatList(value=[value]))

        example_proto = tf.train.Example(features=tf.train.Features(feature=feature))
        return example_proto.SerializeToString()



