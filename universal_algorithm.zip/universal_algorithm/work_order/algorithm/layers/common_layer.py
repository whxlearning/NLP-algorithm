from tensorflow.keras.layers import Activation, BatchNormalization, Layer, Dropout
import tensorflow as tf
import math


def gelu(x):
    """
    https://arxiv.org/pdf/1606.08415.pdf
    """
    c = math.sqrt(2 / math.pi)
    return 0.5 * x * (1 + tf.tanh(c * (x + 0.044715 * tf.pow(x, 3))))


class LayerNormalization(Layer):
    """
    Implementation of Layer Normalization (https://arxiv.org/abs/1607.06450).
    """
    def __init__(self, epsilon=1e-5, axis=-1, **kwargs):
        self.axis = axis
        self.epsilon = epsilon
        super().__init__(**kwargs)

    def get_config(self):
        config = super().get_config()
        config['axis'] = self.axis
        config['epsilon'] = self.epsilon
        return config

    def build(self, input_shape):
        dim = input_shape[-1]
        self.gain = self.add_weight(
            name='gain',
            shape=(dim,),
            initializer='ones',
            trainable=True)
        self.bias = self.add_weight(
            name='bias',
            shape=(dim,),
            initializer='zeros',
            trainable=True)
        return super().build(input_shape)

    def call(self, inputs, **kwargs):
        mean = tf.reduce_mean(inputs, axis=self.axis, keepdims=True)
        variance = tf.reduce_mean(tf.square(inputs - mean), axis=self.axis, keepdims=True)
        epsilon = tf.constant(self.epsilon, dtype=tf.float32)
        normalized_inputs = (inputs - mean) / tf.sqrt(variance + epsilon)
        result = self.gain * normalized_inputs + self.bias
        return result
