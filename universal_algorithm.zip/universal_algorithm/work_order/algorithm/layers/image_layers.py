import tensorflow as tf
from tensorflow.python.keras import backend as K
from tensorflow.python.keras.layers import Activation, BatchNormalization, Layer, Dropout, Conv2D, MaxPool2D, Dense, Flatten

class LeNet(Layer):
    def __init__(self, ):
        pass

class AlexNet(Layer):
    # input_shape=(227, 227, 3)
    def __init__(self, hidden_units):
        self.hidden_units = hidden_units
        super(AlexNet, self).__init__()

    def build(self, input_shape):

        self.input_layer = Conv2D(
            filters=96,
            kernel_size=(11, 11),
            strides=(4, 4),
            activation=Activation('relu'),
            padding='valid',
            input_shape=input_shape)

        # 以列表的形式来构建网络模型
        self.middle_layers = [
            BatchNormalization(),
            MaxPool2D(pool_size=(3, 3), strides=(2, 2)),
            Conv2D(
                filters=256,
                kernel_size=(5, 5),
                strides=(1, 1),
                activation=Activation('relu'),
                padding='same'
            ),
            BatchNormalization(),
            MaxPool2D(pool_size=(3, 3), strides=(2, 2)),

            Conv2D(
                filters=384,
                kernel_size=(3, 3),
                strides=(1, 1),
                activation=Activation('relu'),
                padding='same'
            ),
            BatchNormalization(),

            Conv2D(
                filters=384,
                kernel_size=(3, 3),
                strides=(1, 1),
                activation=Activation('relu'),
                padding='same'
            ),
            BatchNormalization(),

            Conv2D(
                filters=256,
                kernel_size=(3, 3),
                strides=(1, 1),
                activation=Activation('relu'),
                padding='same'
            ),
            BatchNormalization(),
            MaxPool2D(pool_size=(3, 3), strides=(2, 2)),
            Flatten(),
            Dense(units=4096, activation=Activation('relu')),
            Dropout(rate=0.5),
            Dense(units=4096, activation=Activation('relu')),
            Dropout(rate=0.5),
        ]

        #全连接层
        self.out_layer = Dense(units=self.hidden_units, activation=Activation('softmax'))
        super().build(input_shape)

    def call(self, inputs):
        x = self.input_layer(inputs)
        for layer in self.middle_layers:
            x = layer(x)
        output = self.out_layer(x)
        return output