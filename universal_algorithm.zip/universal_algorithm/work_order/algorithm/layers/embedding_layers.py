import tensorflow as tf
from tensorflow.keras.layers import Layer, Embedding
import math
from tensorflow.keras.layers import Embedding, GRU, Conv2D, MaxPool2D, GlobalMaxPooling1D
from tensorflow.keras.layers import SpatialDropout1D, Conv1D, Flatten, Add, MaxPooling1D
from tensorflow.keras.layers import BatchNormalization, Dropout, Bidirectional
from tensorflow.keras.regularizers import l2

from ..layers.attention_BiRNN import Attention
from ..layers.attention_layers import TransformerBlock
from ..layers.capsule_layers import *


class PositionEmbedding(Layer):
    def __init__(self, **kwargs):
        super(PositionEmbedding, self).__init__(**kwargs)

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        inputs_shape = inputs.shape.as_list()
        batch_size = tf.shape(inputs)[0]
        seq_len = inputs_shape[1]
        embedding_size = inputs_shape[2]
        positions = tf.range(seq_len) + 1
        positions_embedding = Embedding(seq_len + 1, embedding_size)(positions)
        positions_embedding = tf.expand_dims(positions_embedding, 0)
        positions_embedding = tf.tile(positions_embedding, [batch_size, 1, 1])
        return positions_embedding + inputs

class SinusoidalPositionEmbedding(Layer):
    def __init__(self, **kwargs):
        super(SinusoidalPositionEmbedding, self).__init__(**kwargs)

    def build(self, input_shape):
        super().build(input_shape)

    @staticmethod
    def embedding(positions, embedding_size):
        positions = tf.cast(positions, tf.float32)
        log_timescale_increment = math.log(10000) / (embedding_size / 2 - 1)
        inv_timescales = tf.exp(tf.range(embedding_size / 2, dtype=tf.float32) * -log_timescale_increment)
        inv_timescales = tf.reshape(inv_timescales, [1, -1])
        scaled_time = tf.expand_dims(positions, -1) * tf.expand_dims(inv_timescales, 1)
        embedding = tf.concat([tf.sin(scaled_time), tf.cos(scaled_time)], axis=2)
        return embedding

    def call(self, inputs, **kwargs):
        inputs_shape = inputs.shape.as_list()
        batch_size = tf.shape(inputs)[0]
        seq_len = inputs_shape[1]
        embedding_size = inputs_shape[2]
        positions = tf.range(seq_len) + 1
        positions_embedding = self.embedding([positions], embedding_size)
        positions_embedding = tf.tile(positions_embedding, [batch_size, 1, 1])
        return positions_embedding + inputs

class Bert_CNN(Layer):
    pass

class Bert_RNN(Layer):
    pass

class CNN_LSTM(Layer):
    pass

class TextCNN(Layer):
    def __init__(self, embedding_size, max_len, **kwargs):
        super(TextCNN, self).__init__(**kwargs)
        self.embedding_size = embedding_size
        self.max_len = max_len

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        embedding = inputs
        embedding = tf.expand_dims(embedding, -1)
        maxpools = []
        for i, filter_size in enumerate([2, 3, 4]):
            filter_size = int(filter_size)
            conv_layer = Conv2D(100,
                                kernel_size=(filter_size, self.embedding_size),
                                padding='valid',
                                kernel_initializer='normal', activation='relu')
            conv = conv_layer(embedding)
            maxpool_layer = MaxPool2D(
                pool_size=(self.max_len - filter_size + 1, 1), strides=(1, 1),
                padding='valid')
            maxpool = maxpool_layer(conv)
            maxpools.append(maxpool)

        h_pool = tf.concat(maxpools, -1)
        num_filters_total = 100 * len([2, 3, 4])
        h_pool_flat = tf.reshape(h_pool, [-1, num_filters_total])

        conv_veritcal_layer = Conv2D(1,
                                     kernel_size=(self.max_len, 1),
                                     padding='valid',
                                     kernel_initializer='normal', activation='relu')
        conv_veritcal = conv_veritcal_layer(embedding)
        vcnn_flat = tf.reshape(conv_veritcal, [-1, self.embedding_size])

        final = tf.concat([h_pool_flat, vcnn_flat], -1)
        return final

class RCNN_variant(Layer):
    def __init__(self, embedding_size, max_len, **kwargs):
        super(RCNN_variant, self).__init__(**kwargs)
        self.embedding_size = embedding_size
        self.max_len = max_len
        self.kernel_sizes = [1, 2, 3, 4]

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        embedding = inputs
#         embedding = tf.expand_dims(embedding, -1)
        x_context = tf.keras.layers.Bidirectional(tf.keras.layers.GRU(64, return_sequences=True))(embedding)  # LSTM or GRU
        x = tf.keras.layers.Concatenate()([embedding, x_context])
        convs = []
        for i in range(len(self.kernel_sizes)):
            conv = tf.keras.layers.Conv1D(64, self.kernel_sizes[i], activation='relu')(x)
            convs.append(conv)
        poolings = [tf.keras.layers.GlobalAveragePooling1D()(conv) for conv in convs] + [
            tf.keras.layers.GlobalMaxPooling1D()(conv) for conv in convs]
        network_out = tf.keras.layers.Concatenate()(poolings)
        # network_out = Dense(len(self._schema_dict['label_list']), activation='relu')(x)
        return network_out

class BiLSTM(Layer):
    def __init__(self, embedding_size, max_len, **kwargs):
        super(BiLSTM, self).__init__(**kwargs)
        self.embedding_size = embedding_size
        self.max_len = max_len

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        embedding = inputs
#         embedding = tf.expand_dims(embedding, -1)
        network_out = tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(64))(embedding)
        # network_out = Dense(len(self._schema_dict['label_list']), activation='relu')(network_out)
        return network_out

class BiGRU(Layer):
    def __init__(self, embedding_size, max_len, **kwargs):
        super(BiGRU, self).__init__(**kwargs)
        self.embedding_size = embedding_size
        self.max_len = max_len

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        embedding = inputs
#         embedding = tf.expand_dims(embedding, -1)
        network_out = tf.keras.layers.Bidirectional(tf.keras.layers.GRU(64))(embedding)
        # network_out = Dense(len(self._schema_dict['label_list']), activation='relu')(network_out)
        return network_out

class TextAttBiRNN(Layer):
    def __init__(self, embedding_size, max_len, **kwargs):
        super(TextAttBiRNN, self).__init__(**kwargs)
        self.embedding_size = embedding_size
        self.max_len = max_len

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        embedding = inputs
#         embedding = tf.expand_dims(embedding, -1)
        bi_rnn = tf.keras.layers.Bidirectional(tf.keras.layers.GRU(64, return_sequences=True))(embedding)  # LSTM or GRU
        network_out = Attention(self.max_len)(bi_rnn)
        # network_out = Dense(len(self._schema_dict['label_list']), activation='relu')(attention)
        return network_out

class Transformer(Layer):
    def __init__(self, embedding_size, max_len, **kwargs):
        super(Transformer, self).__init__(**kwargs)
        self.embedding_size = embedding_size
        self.max_len = max_len

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        embedding = inputs
#         embedding = tf.expand_dims(embedding, -1)
        #Transformer
        transformer_block = TransformerBlock(
            name='transformer',
            num_heads=4,
            residual_dropout=0.1,
            attention_dropout=0.1,
            use_masking=True)
        transformer = transformer_block(embedding)
        network_out = GlobalMaxPooling1D()(transformer)
        # network_out = Dense(len(self._schema_dict['label_list']), activation='relu')(network_out)
        return network_out

class DPCNN(Layer):
    def __init__(self, embedding_size, max_len, **kwargs):
        super(DPCNN, self).__init__(**kwargs)
        self.embedding_size = embedding_size
        self.max_len = max_len

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        embedding = inputs
        text_embed = SpatialDropout1D(0.2)(embedding)

        repeat = 3
        size = self.max_len
        region_x = Conv1D(filters=250, kernel_size=3, padding='same', strides=1)(text_embed)
        x = Activation(activation='relu')(region_x)
        x = Conv1D(filters=250, kernel_size=3, padding='same', strides=1)(x)
        x = Activation(activation='relu')(x)
        x = Conv1D(filters=250, kernel_size=3, padding='same', strides=1)(x)
        x = Add()([x, region_x])

        for _ in range(repeat):
            px = MaxPooling1D(pool_size=3, strides=2, padding='same')(x)
            size = int((size + 1) / 2)
            x = Activation(activation='relu')(px)
            x = Conv1D(filters=250, kernel_size=3, padding='same', strides=1)(x)
            x = Activation(activation='relu')(x)
            x = Conv1D(filters=250, kernel_size=3, padding='same', strides=1)(x)
            x = Add()([x, px])

        x = MaxPooling1D(pool_size=size)(x)
        network_out = Flatten()(x)

        return network_out

class CRNN(Layer):
    def __init__(self, embedding_size, max_len, **kwargs):
        super(CRNN, self).__init__(**kwargs)
        self.embedding_size = embedding_size
        self.max_len = max_len

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        embedding = inputs
        text_embed = SpatialDropout1D(0.2)(embedding)

        conv_layer = Conv1D(300, kernel_size=3, padding="valid", activation='relu')(text_embed)
        conv_max_pool = MaxPooling1D(pool_size=2)(conv_layer)

        gru_layer = tf.keras.layers.Bidirectional(tf.keras.layers.GRU(64))(conv_max_pool)
        network_out = GlobalMaxPooling1D()(gru_layer)

        return network_out

class Capnet_CNN(Layer):
    def __init__(self, embedding_size, max_len, **kwargs):
        super(Capnet_CNN, self).__init__(**kwargs)
        self.embedding_size = embedding_size
        self.max_len = max_len

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        embedding = inputs
        conv_3 = Activation(activation="relu")(BatchNormalization()(Conv1D(filters=128, kernel_size=3, padding="valid")(embedding)))
        x_3 = Capsule(
            num_capsule=4, dim_capsule=16,
            routings=4, share_weights=True)(conv_3)
        network_out = Flatten()(x_3)
        network_out = Dropout(0.2)(network_out)

        return network_out

class Capnet_RNN(Layer):
    def __init__(self, embedding_size, max_len, **kwargs):
        super(Capnet_RNN, self).__init__(**kwargs)
        self.embedding_size = embedding_size
        self.max_len = max_len

    def build(self, input_shape):
        super().build(input_shape)

    def call(self, inputs, **kwargs):
        embedding = inputs
        network_out = SpatialDropout1D(0.2)(embedding)
        network_out = tf.keras.layers.Bidirectional(tf.keras.layers.GRU(64, return_sequences=True))(network_out)
        network_out = Capsule(
            num_capsule=4, dim_capsule=16,
            routings=4, share_weights=True)(network_out)
        network_out = Flatten()(network_out)
        network_out = Dropout(0.2)(network_out)

        return network_out