import pandas as pd
from algorithm.toolbox.ctr_box import *
from algorithm.datasets.tabular_dataset import *
from algorithm.models.xdeepfm import XFM
from algorithm.models.fm import FM
from algorithm.models.deepfm import DeepFM
from algorithm.models.widedeep import WideDeep
import numpy as np
from terminaltables import AsciiTable

flags = tf.flags
FLAGS = flags.FLAGS

flags.DEFINE_string("train_file", '', "The input file dir.")  # 训练数据
flags.DEFINE_string("test_file", '', "The input file dir.")   # 测试数据
flags.DEFINE_string("base_path", '', "the file save path")  # 模型中间文件保存地址
flags.DEFINE_string("label_name", 'rating', "label name")
flags.DEFINE_string("seq_sep_feature", '|', "seq_sep_feature")
flags.DEFINE_string("w2v_path", '', "w2v_path")

def word_emb(model):
    def tool(x):
        count = 0
        sentence_vec = np.zeros((300,))
        if isinstance(x, str):
            for i in list(x):
                if i != np.NAN:
                    try:
                        word_vec = model[i]
                        #sentence_vec = np.maximum(sentence_vec, word_vec)         #最大池化层（效率比较高）
                        sentence_vec += word_vec                                   #平均池化层
                        count += 1
                    except KeyError:
                        pass
                    except TypeError:
                        pass
        if count == 0:
            return sentence_vec
        return sentence_vec / count

    return tool

def process_data():
    train_data = pd.read_csv(FLAGS.train_file)  # 读取数据
    test_data = pd.read_csv(FLAGS.test_file)  # 读取数据
    dense_feature = []
    vector_feature = []
    seq_feature = ['genres']
    sparse_feature = ['userId', 'movieId']
    text_feature = []

    # for s in sparse_feature:  # 格式转换
    #     if train_data[s].dtypes == float:
    #         train_data[s] = train_data[s].astype(int)
    #
    # for s in sparse_feature:  # 格式转换
    #     if test_data[s].dtypes == float:
    #         test_data[s] = test_data[s].astype(int)

    feature = sparse_feature + vector_feature + dense_feature + seq_feature + text_feature

    train_data.dropna(inplace=True)  # 去除缺失值数据
    print('去除缺失值后训练数据集', len(train_data))
    train_data.drop_duplicates(subset=feature, inplace=True)
    print('去重后训练数据集', len(train_data))
    # 列表去重有问题，放到去重后再把字符串列表化
    # 为什么要有这一步？
    # for t in text_feature:
    #     train_data[t] = train_data[t].apply(lambda x: json.loads(x))
    #
    # for t in text_feature:
    #     test_data[t] = test_data[t].apply(lambda x: json.loads(x))
    return train_data, test_data, dense_feature, sparse_feature, seq_feature, vector_feature, text_feature

def map_and_pad(max_len):
    def func(x):
        while len(x) < max_len:
            x.append(0)
        return x[:max_len]
    return func

def main(_):
    path = FLAGS.base_path
    train_data, test_data, dense_feature, sparse_feature, seq_feature, vector_feature, text_feature = process_data()  # 处理数据
    print(train_data['rating'].value_counts())

    df = pd.concat([train_data, test_data])
    print(len(df))

    vector_dict = {v: 300 for v in vector_feature}



    schema_dict = build_schema_dict(df, dense_feature, sparse_feature, seq_feature, vector_dict,text_feature,
                                    FLAGS.label_name,
                                    train_data[FLAGS.label_name].unique().tolist(),
                                    path + 'schema_dict.json')  # 生成大纲文件

    #
    # schema_path = path + 'schema_dict.json'
    # with open(schema_path, 'r') as f:
    #     schema_dict = json.load(f)
    #

    # start = time.time()
    # model = gensim.models.KeyedVectors.load_word2vec_format(FLAGS.w2v_path)
    # #model = gensim.models.Word2Vec.load(FLAGS.w2v_path)
    # #model = gensim.models.KeyedVectors.load_word2vec_format('D:/my_jd_coding/work_order1/word2vec_model/Tencent_AILab_ChineseEmbedding.txt') #也可以加載騰訊詞向量
    # end = time.time()
    # print('加载词向量耗时:' + str(end-start))

    # for v in vector_feature:
    #     data[v] = data[v].apply(word_emb(model))

    for s in sparse_feature:
        train_data[s] = train_data[s].map(schema_dict['sparse_feature_vocab'][s])  # 根据关系表映射
    # for s in dense_feature:
    #     train_data[s].fillna(schema_dict['dense_feature'][s])


    for s in sparse_feature:
        test_data[s] = test_data[s].map(schema_dict['sparse_feature_vocab'][s])  # 根据关系表映射
    # for s in dense_feature:
    #     test_data[s].fillna(schema_dict['dense_feature'][s])




    #多值离散特征的映射
    for m_s in seq_feature:
        for index, content in enumerate(train_data[m_s]):
            content = [x for x in content.split(FLAGS.seq_sep_feature)]
            train_data[m_s][index] = list(map(lambda x: schema_dict['seq_feature_vocab'][m_s][x], content))

    for s in seq_feature:
        train_data[s] = train_data[s].apply(map_and_pad(schema_dict['seq_feature'][s]['len']))

    for m_s in seq_feature:
        for index, content in enumerate(test_data[m_s]):
            content = [x for x in content.split(FLAGS.seq_sep_feature)]
            test_data[m_s][index] = list(map(lambda x: schema_dict['seq_feature_vocab'][m_s][x], content))

    for s in seq_feature:
        test_data[s] = test_data[s].apply(map_and_pad(schema_dict['seq_feature'][s]['len']))


    # for t_s in text_feature:
    #     for index, content in enumerate(train_data[t_s]):
    #         content = [x for x in list(content)]
    #         train_data[t_s][index] = list(map(lambda x: schema_dict['text_feature_vocab'][t_s][x], content))
    # for t in text_feature:
    #     train_data[t] = train_data[t].apply(map_and_pad(schema_dict['text_feature'][t]['len']))
    #
    # for t_s in text_feature:
    #     for index, content in enumerate(test_data[t_s]):
    #         content = [x for x in list(content)]
    #         test_data[t_s][index] = list(map(lambda x: schema_dict['text_feature_vocab'][t_s][x], content))
    # for t in text_feature:
    #     test_data[t] = test_data[t].apply(map_and_pad(schema_dict['text_feature'][t]['len']))

    #数据概览
    inquire = train_data.head(5)
    head = list(inquire)
    data_inquire = [head]
    content = inquire.values.tolist()
    for i in range(len(content)):
        data_inquire.append(content[i])
    data_inquire = AsciiTable(data_inquire)
    print(data_inquire.table)
    # #
    output_num = 2
    #
    TfrecordBuilder(train_data, path + 'schema_dict.json', path + 'train.tfrecord', output_num=output_num)  # 生产训练所需要的tfrecord文件
    #   混淆矩阵使用
    #data_original = data[num:]
    TfrecordBuilder(test_data, path + 'schema_dict.json', path + 'test.tfrecord', output_num=output_num) # 生产验证所需要的tfrecord文件
    #
    trainset = TabularDataSet(path + 'schema_dict.json', [path + 'train.tfrecord'], True, 1, 512, output_num=output_num)  # 载入数据转化为tf.data结构
    validset = TabularDataSet(path + 'schema_dict.json', path + 'train.tfrecord', True, 1, 512, output_num=output_num)

    # 混淆矩阵使用
    #   ----------------------------------------------------------------------------------------------
    # preset = TabularDataSet(path + 'schema_dict.json', path + 'test.tfrecord', False, 1, 512, output_num=output_num)
    # #   ----------------------------------------------------------------------------------------------
    model = WideDeep('BiLSTM', path + 'schema_dict.json', 10, [512, 128], model_dir=path + 'model', output_mode=1, output_num=output_num, model_type='classify')  # 选择训练模型
    # #
    model.fit(trainset)
    model.eval(validset)
    # # 混淆矩阵
    # # --------------------------------------------------------------
    # # 混淆矩阵输出文件
    #
    # predict_pro = []
    # for label in model.predict(preset):
    #     predict_pro.append(label['predictions'][0]) #output_mode=0的时候这么取
    #     #predict_pro.append(label['label_ids'][0])
    #
    # pred = pd.DataFrame({'original': test_data['target'], 'predict_score': predict_pro})
    # pred.columns = ['real_label', 'predict_score']
    # pred.to_csv('D:/工程代码/universal_algorithm/output/output.csv', index=False)
    #
    # #tf.serving服务文件
    # model.save_for_server(path + 'serving')

tf.app.run(main)
